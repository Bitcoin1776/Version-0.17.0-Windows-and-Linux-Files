#!/usr/bin/env bash

export LC_ALL=C
TOPDIR=${TOPDIR:-$(git rev-parse --show-toplevel)}
BUILDDIR=${BUILDDIR:-$TOPDIR}

BINDIR=${BINDIR:-$BUILDDIR/src}
MANDIR=${MANDIR:-$TOPDIR/doc/man}

BITCOIN1776D=${BITCOIN1776D:-$BINDIR/bitcoin1776d}
BITCOIN1776CLI=${BITCOIN1776CLI:-$BINDIR/bitcoin1776-cli}
BITCOIN1776TX=${BITCOIN1776TX:-$BINDIR/bitcoin1776-tx}
BITCOIN1776QT=${BITCOIN1776QT:-$BINDIR/qt/bitcoin1776-qt}

[ ! -x $BITCOIN1776D ] && echo "$BITCOIN1776D not found or not executable." && exit 1

# The autodetected version git tag can screw up manpage output a little bit
JFKVER=($($BITCOIN1776CLI --version | head -n1 | awk -F'[ -]' '{ print $6, $7 }'))

# Create a footer file with copyright content.
# This gets autodetected fine for bitcoin1776d if --version-string is not set,
# but has different outcomes for bitcoin1776-qt and bitcoin1776-cli.
echo "[COPYRIGHT]" > footer.h2m
$BITCOIN1776D --version | sed -n '1!p' >> footer.h2m

for cmd in $BITCOIN1776D $BITCOIN1776CLI $BITCOIN1776TX $BITCOIN1776QT; do
  cmdname="${cmd##*/}"
  help2man -N --version-string=${JFKVER[0]} --include=footer.h2m -o ${MANDIR}/${cmdname}.1 ${cmd}
  sed -i "s/\\\-${JFKVER[1]}//g" ${MANDIR}/${cmdname}.1
done

rm -f footer.h2m
